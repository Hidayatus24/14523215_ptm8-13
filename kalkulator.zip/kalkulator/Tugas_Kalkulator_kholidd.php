<!DOCTYPE html>
<html>
<head>
    <title>Kalkulator Aritmatika Sederhana</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #f0f8ff, #e6f2ff);
            text-align: center;
            margin-top: 100px;
        }
        h2 {
            color: #333;
        }
        form {
            background-color: #ffffff;
            padding: 20px;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }
        input, select {
            margin: 10px;
            padding: 8px;
            width: 180px;
            font-size: 16px;
        }
        input[type=submit] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type=submit]:hover {
            background-color: #45a049;
        }
        .hasil {
            margin-top: 20px;
            font-size: 20px;
            color: #000;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>Kalkulator Aritmatika PHP</h2>

    <form method="post" action="">
        <input type="number" name="angka1" placeholder="Masukkan angka pertama" required>

        <select name="operator">
            <option value="+">Tambah (+)</option>
            <option value="-">Kurang (-)</option>
            <option value="&#42;">Kali (*)</option>
            <option value="/">Bagi (/)</option>
        </select>

        <input type="number" name="angka2" placeholder="Masukkan angka kedua" required>
        <br>

        <input type="submit" name="hitung" value="Hitung">
    </form>

    <?php
    if (isset($_POST['hitung'])) {
        $angka1 = $_POST['angka1'];
        $angka2 = $_POST['angka2'];
        $operator = $_POST['operator'];

        if ($operator == "+") {
            $hasil = $angka1 + $angka2;
        } elseif ($operator == "-") {
            $hasil = $angka1 - $angka2;
        } elseif ($operator == "*") {
            $hasil = $angka1 * $angka2;
        } elseif ($operator == "/") {
            if ($angka2 == 0) {
                $hasil = "Tidak bisa dibagi dengan nol";
            } else {
                $hasil = $angka1 / $angka2;
            }
        } else {
            $hasil = "Operator tidak dikenali";
        }

        echo "<div class='hasil'>Hasil: $hasil</div>";
    }
    ?>

</body>
</html>
