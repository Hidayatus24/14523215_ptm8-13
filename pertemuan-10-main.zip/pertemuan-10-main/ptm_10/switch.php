<?php

$role = "admin";
switch($role){
    case "admin":
        echo "akses penuh sistem <br>";
        break;
    case "mahasiswa":
        echo "akses data KRS <br>";
        break;
    default:
        echo "role tidak ditemukan <br>";
        break;
}
?>
<br>
<a href="index.php">Kembali ke menu utama</a>