<?php
$umur =17;
echo "<h1> Codingan if </h1>";
if ($umur >= 18){
    echo "Anda Sudah Dewasa ";
} elseif ($umur >= 13 ){
    echo "Anda Remaja";
}else{
    echo "Anda Anak-Anak";
}
?>
<br>