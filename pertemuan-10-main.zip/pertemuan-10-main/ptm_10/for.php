<?php
echo "<h1> Codingan For</h1>";

for ($i = 2;$i <= 10;$i +=2){
    echo "angka : ".$i."<br>";
}
echo "<h1> codingan while </h1>";
$j = 2;
while ($j <= 10){
    echo "angka : .$j.";
    $j +=2;
}